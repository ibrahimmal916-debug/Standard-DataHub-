-- Standard DataHub Supabase schema. Apply using the Supabase SQL editor.
-- Wallet and transaction mutations must go through the authenticated server API.
-- The application server connects using DATABASE_URL; never expose that credential in VITE_* variables.

CREATE TABLE IF NOT EXISTS public.wallet (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id TEXT NOT NULL UNIQUE,
  balance NUMERIC(14,2) NOT NULL DEFAULT 0 CHECK (balance >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.data_plans (
  id TEXT PRIMARY KEY,
  network TEXT NOT NULL,
  plan_name TEXT NOT NULL,
  plan_type TEXT NOT NULL DEFAULT 'SME',
  data_amount TEXT NOT NULL,
  duration TEXT NOT NULL DEFAULT '30 Days',
  selling_price_kobo NUMERIC NOT NULL CHECK (selling_price_kobo >= 0),
  selling_price_naira NUMERIC NOT NULL CHECK (selling_price_naira >= 0),
  provider_code TEXT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT true,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  reference TEXT NOT NULL UNIQUE,
  user_id TEXT NOT NULL,
  product_type TEXT NOT NULL CHECK (product_type IN ('data','airtime')),
  network TEXT NOT NULL,
  recipient_phone TEXT NOT NULL,
  amount_naira NUMERIC NOT NULL CHECK (amount_naira >= 0),
  selling_price_kobo NUMERIC NOT NULL CHECK (selling_price_kobo >= 0),
  status TEXT NOT NULL,
  provider TEXT DEFAULT 'ClubKonnect',
  provider_reference TEXT,
  refund_reference TEXT,
  error_message TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.wallet ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.data_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;

-- Remove historically permissive policies. No direct browser wallet/transaction access:
-- the backend uses its private PostgreSQL connection and enforces application roles.
DROP POLICY IF EXISTS "allow_all" ON public.wallet;
DROP POLICY IF EXISTS "allow_all" ON public.data_plans;
DROP POLICY IF EXISTS "allow_all" ON public.transactions;
DROP POLICY IF EXISTS "wallet_read_own" ON public.wallet;
DROP POLICY IF EXISTS "transactions_read_own" ON public.transactions;
DROP POLICY IF EXISTS "data_plans_public_read" ON public.data_plans;

CREATE POLICY "data_plans_public_read" ON public.data_plans
  FOR SELECT TO anon, authenticated USING (is_active = true);
-- Intentionally no anon/authenticated policies on wallet or transactions.
-- Service operations must use the server's protected DATABASE_URL, never a service-role key in frontend code.

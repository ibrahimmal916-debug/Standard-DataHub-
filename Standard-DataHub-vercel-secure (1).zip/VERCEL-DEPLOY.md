# Standard DataHub — Vercel deployment

## Deploy
1. Push this project to a private GitHub repository (do not commit `.env` files).
2. Import the repository in https://vercel.com/new. Framework preset: Vite (or Other if prompted); build command `npm run build`; output directory `dist`. The included `vercel.json` configures the API function and SPA fallback.
3. In Project Settings → Environment Variables, add the required variables below for Production and Preview as appropriate, then redeploy.

## Required Vercel Environment Variables
- `VITE_SUPABASE_URL` = `https://knnynfgtewbnvvcgelef.supabase.co` (public project URL)
- `VITE_SUPABASE_ANON_KEY` = Supabase publishable key (public browser key; RLS is mandatory)
- `DATABASE_URL` = Supabase PostgreSQL connection string (server only; use Supabase Connect panel, preferably pooler connection for serverless)
- `JWT_SECRET` = unique random secret of at least 32 characters; do not reuse an example/default
- `CLUBKONNECT_USER_ID` = ClubKonnect user ID (server only)
- `CLUBKONNECT_API_KEY` = ClubKonnect API key (server only)
- `CLUBKONNECT_BASE_URL` = `https://www.nellobytesystems.com` (confirm the correct API base URL from your ClubKonnect documentation/account)
- `DEMO_MODE` = `true` for testing; switch to `false` only after live provider credentials, wallet ledger, RLS, and transaction flows have been tested

Never prefix private credentials with `VITE_`. Never put Supabase `service_role`/secret keys, database passwords, ClubKonnect keys, or JWT secret in frontend code.

## Important compatibility notes
- This project uses a PostgreSQL connection pool and database initialization. Serverless functions may reuse warm instances but do not guarantee persistent process lifetime; verify connection pooling and schema initialization under real traffic.
- The API function entry point is `api/index.ts`, which imports the existing Express app. Vercel Functions are not a permanent always-on server.
- Run the SQL schema and review all RLS policies in Supabase before production. Do not use permissive `allow_all` policies.
- Environment variable changes require a new deployment.
- Test `/api/health`, authentication, wallet reads/writes, and a ClubKonnect sandbox/test transaction before enabling live transactions.

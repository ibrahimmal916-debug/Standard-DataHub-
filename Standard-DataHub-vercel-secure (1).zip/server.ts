import express from 'express';
import cors from 'cors';
import path from 'path';
import fs from 'fs';
import dotenv from 'dotenv';
import { initDatabase } from './server/db/init.ts';
import { closeDb } from './server/db/database.ts';
import authRoutes from './server/routes/authRoutes.ts';
import walletRoutes from './server/routes/walletRoutes.ts';
import vtuRoutes from './server/routes/vtuRoutes.ts';
import adminRoutes from './server/routes/adminRoutes.ts';

dotenv.config({ override: true });

// Ensure ClubKonnect environment aliases and defaults are aligned without hardcoding
if (process.env.CLUBKONNECT_USER_ID && !process.env.CLUBKONNECT_U) {
  process.env.CLUBKONNECT_U = process.env.CLUBKONNECT_USER_ID;
}
if (process.env.CLUBKONNECT_U && !process.env.CLUBKONNECT_USER_ID) {
  process.env.CLUBKONNECT_USER_ID = process.env.CLUBKONNECT_U;
}
if (process.env.CLUBKONNECT_API_KEY && !process.env.CLUBKONNECT_A) {
  process.env.CLUBKONNECT_A = process.env.CLUBKONNECT_API_KEY;
}
if (process.env.CLUBKONNECT_A && !process.env.CLUBKONNECT_API_KEY) {
  process.env.CLUBKONNECT_API_KEY = process.env.CLUBKONNECT_A;
}
process.env.CLUBKONNECT_BASE_URL = process.env.CLUBKONNECT_BASE_URL || 'https://www.nellobytesystems.com';

const app = express();
export default app;

// Vercel runs this Express app as a serverless function. Initialize cloud DB once per warm instance.
let vercelInitPromise: Promise<void> | null = null;
if (process.env.VERCEL) {
  app.use(async (_req, res, next) => {
    try {
      const jwtSecret = process.env.JWT_SECRET?.trim() || '';
      if (jwtSecret.length < 32 || /change.?me|default|example|placeholder/i.test(jwtSecret)) {
        return res.status(503).json({ error: 'Server configuration incomplete: JWT_SECRET must be set in Vercel Environment Variables.' });
      }
      if (!vercelInitPromise) vercelInitPromise = initDatabase();
      await vercelInitPromise;
      next();
    } catch (error) {
      vercelInitPromise = null;
      console.error('[Vercel] Cloud database initialization failed:', error);
      res.status(503).json({ error: 'Cloud database unavailable. Check Vercel environment variables and Supabase connectivity.' });
    }
  });
}
const isProduction = process.env.NODE_ENV === 'production';
// AI Studio dev server must run strictly on port 3000
const PORT = !isProduction ? 3000 : (Number(process.env.PORT) || 3000);

// Basic security and parsing middlewares
app.use(cors());
app.use(express.json({ limit: '25mb' }));
app.use(express.urlencoded({ extended: true, limit: '25mb' }));

// Health and Diagnostics
app.get('/api/health', (_req, res) => {
  const isDemo = process.env.DEMO_MODE !== 'false';
  res.json({
    status: 'ok',
    service: 'DataHub VTU API',
    demoMode: isDemo,
    mode: isDemo ? 'simulation' : 'production',
    provider: {
      name: 'ClubKonnect',
      liveMode: !isDemo,
      configured: Boolean(
        (process.env.CLUBKONNECT_U || process.env.CLUBKONNECT_USER_ID) &&
        (process.env.CLUBKONNECT_A || process.env.CLUBKONNECT_API_KEY)
      )
    },
    time: new Date().toISOString()
  });
});

// API Routes
app.use('/api/auth', authRoutes);
app.use('/api/wallet', walletRoutes);
app.use('/api/vtu', vtuRoutes);
app.use('/api/admin', adminRoutes);

async function startServer() {
  try {
    const jwtSecret = process.env.JWT_SECRET?.trim() || '';
    if (jwtSecret.length < 32 || /change.?me|default|example|placeholder/i.test(jwtSecret)) {
      throw new Error('Set JWT_SECRET to a unique random secret of at least 32 characters in the server environment.');
    }
    // Cloud PostgreSQL is mandatory; there is no local database fallback.
    // Initialize PostgreSQL schema and seed records
    await initDatabase();

    if (!isProduction) {
      // Development mode: Vite middleware
      const { createServer: createViteServer } = await import('vite');
      const vite = await createViteServer({
        server: { middlewareMode: true },
        appType: 'spa'
      });
      app.use(vite.middlewares);
      console.log('Vite development server middleware mounted.');
    } else {
      // Production mode: Serve built static files
      const distPath = path.resolve(process.cwd(), 'dist');
      if (fs.existsSync(distPath)) {
        app.use(express.static(distPath));
        app.get('*', (_req, res) => {
          res.sendFile(path.join(distPath, 'index.html'));
        });
      }
    }

    if (process.env.VERCEL) return;

    const server = app.listen(PORT, '0.0.0.0', () => {
      console.log(`=========================================`);
      console.log(`  STANDARD DATAHUB VTU SERVER ACTIVE`);
      console.log(`  Port: ${PORT}`);
      console.log(`  Environment: ${process.env.NODE_ENV || 'development'}`);
      console.log(`  Demo Mode: ${process.env.DEMO_MODE !== 'false' ? 'ENABLED (Safe Simulated Top-ups)' : 'LIVE ClubKonnect'}`);
      console.log(`=========================================`);
    });

    const shutdown = async () => {
      console.log('[Server] Gracefully shutting down...');
      server.close(async () => {
        await closeDb();
        process.exit(0);
      });
      setTimeout(() => process.exit(0), 3000);
    };

    process.on('SIGINT', shutdown);
    process.on('SIGTERM', shutdown);
  } catch (err) {
    console.error('Failed to start DataHub server:', err);
    process.exit(1);
  }
}

if (!process.env.VERCEL) {
  startServer();
}

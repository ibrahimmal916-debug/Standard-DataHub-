import pg from 'pg';
import dotenv from 'dotenv';

dotenv.config({ override: true });

export interface QueryResult<T = any> {
  rows: T[];
  rowCount?: number;
}

export interface DbClient {
  query<T = any>(sql: string, params?: any[]): Promise<QueryResult<T>>;
  transaction<T>(fn: (client: DbClient) => Promise<T>): Promise<T>;
}

let pgPoolInstance: pg.Pool | null = null;
let isPostgresServer = false;
let connectionChecked = false;

export function isPostgresActive(): boolean {
  return isPostgresServer;
}

/**
 * Initializes and returns a persistent database client.
 * Connects directly to external Supabase PostgreSQL database for permanent 100% persistent data storage.
 */
export async function getDb(): Promise<DbClient> {
  // If pool already established, return it
  if (pgPoolInstance) {
    return createPgWrapper(pgPoolInstance);
  }

  // Attempt Supabase PostgreSQL connection
  if (!connectionChecked) {
    const rawDbUrl = process.env.DATABASE_URL || '';
    const cleanDbUrl = rawDbUrl.replace(/[\u200B-\u200D\uFEFF\u2060\s]/g, '').trim();

    // 1. Prioritize DATABASE_URL connection string if available and pointing to external host
    if (cleanDbUrl && !cleanDbUrl.includes('localhost') && !cleanDbUrl.includes('127.0.0.1')) {
      try {
        console.log('[Database] Connecting to external PostgreSQL via DATABASE_URL...');
        const candidatePool = new pg.Pool({
          connectionString: cleanDbUrl,
          connectionTimeoutMillis: 10000,
          ssl: { rejectUnauthorized: false }
        });

        await candidatePool.query('SELECT 1');
        pgPoolInstance = candidatePool;
        isPostgresServer = true;
        console.log('[Database] 100% Permanent Supabase PostgreSQL connected successfully via DATABASE_URL!');
      } catch (err: any) {
        console.warn(`[Database] DATABASE_URL connection error (${err?.message || err}).`);
      }
    }

    // 2. If not connected yet, attempt connection via discrete SUPABASE_DB_* parameters
    if (!pgPoolInstance && process.env.SUPABASE_DB_HOST && !process.env.SUPABASE_DB_HOST.includes('your-project-id')) {
      const supabaseHost = process.env.SUPABASE_DB_HOST.trim();
      const supabaseUser = (process.env.SUPABASE_DB_USER || 'postgres').trim();
      const supabasePassword = process.env.SUPABASE_DB_PASSWORD || '';
      const supabaseDb = (process.env.SUPABASE_DB_NAME || 'postgres').trim();
      const supabasePort = Number(process.env.SUPABASE_DB_PORT) || 5432;

      if (supabasePassword) {
        try {
          console.log(`[Database] Connecting to external PostgreSQL at ${supabaseHost}:${supabasePort}...`);
          const candidatePool = new pg.Pool({
            host: supabaseHost,
            port: supabasePort,
            user: supabaseUser,
            password: supabasePassword,
            database: supabaseDb,
            connectionTimeoutMillis: 10000,
            ssl: { rejectUnauthorized: false }
          });

          await candidatePool.query('SELECT 1');
          pgPoolInstance = candidatePool;
          isPostgresServer = true;
          console.log(`[Database] 100% Permanent Supabase PostgreSQL connected successfully (${supabaseHost})!`);
        } catch (err: any) {
          console.warn(`[Database] Supabase discrete connection error (${err?.message || err}).`);
        }
      }
    }

    connectionChecked = true;
  }

  if (pgPoolInstance) {
    return createPgWrapper(pgPoolInstance);
  }

  throw new Error('Cloud database unavailable. Configure DATABASE_URL or SUPABASE_DB_HOST and SUPABASE_DB_PASSWORD. Local SQLite fallback is disabled to prevent data being stored locally.');
}

function createPgWrapper(pool: pg.Pool): DbClient {
  return {
    async query<T = any>(sql: string, params?: any[]): Promise<QueryResult<T>> {
      const cleanParams = (params || []).map(p => (p === undefined ? null : p));
      const res = await pool.query(sql, cleanParams);
      return { rows: res.rows as T[], rowCount: res.rowCount ?? res.rows.length };
    },
    async transaction<T>(fn: (client: DbClient) => Promise<T>): Promise<T> {
      const client = await pool.connect();
      try {
        await client.query('BEGIN');
        const clientWrapper: DbClient = {
          query: async (sql, params) => {
            const cleanParams = (params || []).map(p => (p === undefined ? null : p));
            const res = await client.query(sql, cleanParams);
            return { rows: res.rows, rowCount: res.rowCount ?? res.rows.length };
          },
          transaction: async () => {
            throw new Error('Nested transactions not supported');
          }
        };
        const result = await fn(clientWrapper);
        await client.query('COMMIT');
        return result;
      } catch (err) {
        await client.query('ROLLBACK');
        throw err;
      } finally {
        client.release();
      }
    }
  };
}

export async function closeDb(): Promise<void> {
  if (pgPoolInstance) {
    try {
      await pgPoolInstance.end();
      pgPoolInstance = null;
      connectionChecked = false;
      console.log('[Database] Supabase PostgreSQL connection pool closed.');
    } catch {}
  }
  if (sqliteInstance) {
    try {
      sqliteInstance.close();
      sqliteInstance = null;
      console.log('[Database] SQLite database closed.');
    } catch {}
  }
}

// Vercel Node.js Function entry point for the existing Express API.
import app from '../server.ts';
export default app;

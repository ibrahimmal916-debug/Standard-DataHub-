import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User } from '../types/index.ts';
import { apiRequest, getAuthToken, setAuthToken, clearAuthToken } from '../lib/api.ts';
import { supabase, isSupabaseConfigured } from '../lib/supabase.ts';
import { getSupabaseWallet } from '../lib/supabaseService.ts';

interface AuthContextType {
  user: User | null;
  token: string | null;
  isLoading: boolean;
  hideBalance: boolean;
  isLoggedIn: boolean;
  toggleHideBalance: () => void;
  login: (token: string, user: User) => void;
  logout: () => Promise<void>;
  signOut: () => Promise<void>;
  refreshUser: () => Promise<void>;
  updateBalance: (newBalanceNaira: number) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [token, setToken] = useState<string | null>(getAuthToken());
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [hideBalance, setHideBalance] = useState<boolean>(() => {
    try {
      return localStorage.getItem('standard_vtu_hide_balance') === 'true';
    } catch {
      return false;
    }
  });

  const isLoggedIn = Boolean(user && user.id && user.id !== 0);

  const toggleHideBalance = () => {
    setHideBalance(prev => {
      const next = !prev;
      try {
        localStorage.setItem('standard_vtu_hide_balance', String(next));
      } catch (e) {
        // ignore storage errors
      }
      return next;
    });
  };

  /**
   * Refreshes the authenticated user profile and wallet balance from the backend/database
   */
  const refreshUser = async () => {
    const currentToken = getAuthToken();

    // 1. If we have a stored JWT token, fetch user profile and live wallet balance
    if (currentToken) {
      try {
        const data = await apiRequest<{ user: User }>('/auth/me');
        if (data?.user) {
          setUser(data.user);
          setToken(currentToken);
          return;
        }
      } catch (err) {
        console.warn('[Auth] JWT token expired or invalid:', err);
        clearAuthToken();
        setToken(null);
        setUser(null);
      }
    }

    // 2. Check active Supabase Auth session if available
    if (isSupabaseConfigured) {
      try {
        const { data: { session }, error: sessionError } = await supabase.auth.getSession();
        if (sessionError) {
          console.warn('[Auth] Supabase getSession error:', sessionError);
        }

        if (session?.user) {
          const sbUser = session.user;
          const authUserId = sbUser.id;

          // Attempt to load profile from existing Supabase database by authenticated user ID
          let profile: any = null;

          // Try 1: users table by authenticated user ID
          try {
            const { data: uById } = await supabase
              .from('users')
              .select('*')
              .eq('id', authUserId)
              .maybeSingle();
            if (uById) profile = uById;
          } catch {
            // ignore
          }

          // Try 2: profiles table by authenticated user ID
          if (!profile) {
            try {
              const { data: pById } = await supabase
                .from('profiles')
                .select('*')
                .eq('id', authUserId)
                .maybeSingle();
              if (pById) profile = pById;
            } catch {
              // ignore
            }
          }

          // Try 3: users table by email as secondary match
          if (!profile && sbUser.email) {
            try {
              const { data: uByEmail } = await supabase
                .from('users')
                .select('*')
                .eq('email', sbUser.email)
                .maybeSingle();
              if (uByEmail) profile = uByEmail;
            } catch {
              // ignore
            }
          }

          const walletBal = await getSupabaseWallet(String(profile?.id || authUserId));

          const resolvedUser: User = {
            id: profile?.id || authUserId,
            fullName: profile?.full_name || profile?.name || sbUser.user_metadata?.full_name || sbUser.user_metadata?.name || sbUser.email?.split('@')[0] || 'Standard User',
            email: profile?.email || sbUser.email || '',
            phone: profile?.phone || profile?.phone_number || sbUser.phone || sbUser.user_metadata?.phone || '',
            role: profile?.role || 'user',
            referralCode: profile?.referral_code,
            hasPin: Boolean(profile?.transaction_pin_hash || profile?.pin),
            balanceKobo: Math.round(walletBal * 100),
            balanceNaira: walletBal
          };

          setUser(resolvedUser);
          if (session.access_token) {
            setToken(session.access_token);
            setAuthToken(session.access_token);
          }
          return;
        }
      } catch (sbErr) {
        console.warn('[Auth] Supabase session check error:', sbErr);
      }
    }

    // No valid authenticated session exists: set logged-out state
    setUser(null);
    setToken(null);
  };

  // Initial session check on mount and listen to Supabase auth events
  useEffect(() => {
    let mounted = true;

    const initAuth = async () => {
      try {
        await refreshUser();
      } finally {
        if (mounted) {
          setIsLoading(false);
        }
      }
    };

    initAuth();

    // Listen to Supabase auth state changes
    let authSub: any = null;
    if (isSupabaseConfigured) {
      try {
        const { data } = supabase.auth.onAuthStateChange(async (event, session) => {
          if (event === 'SIGNED_OUT' || !session) {
            clearAuthToken();
            setToken(null);
            setUser(null);
            window.dispatchEvent(new CustomEvent('auth-logout'));
          } else if ((event === 'SIGNED_IN' || event === 'TOKEN_REFRESHED') && session?.user) {
            await refreshUser();
          }
        });
        authSub = data?.subscription;
      } catch (e) {
        // Fallback or ignore
      }
    }

    return () => {
      mounted = false;
      if (authSub?.unsubscribe) {
        authSub.unsubscribe();
      }
    };
  }, []);

  const login = (newToken: string, newUser: User) => {
    setAuthToken(newToken);
    setToken(newToken);
    setUser(newUser);
  };

  /**
   * Proper Sign Out:
   * - Calls Supabase signOut()
   * - Clears JWT token & local session storage
   * - Resets user state to null (no fake Guest Account)
   * - Dispatches 'auth-logout' event for immediate page redirect
   */
  const logout = async () => {
    try {
      if (isSupabaseConfigured) {
        await supabase.auth.signOut();
      }
    } catch (err) {
      console.warn('[Auth] Supabase signOut notice:', err);
    }

    clearAuthToken();
    setToken(null);
    setUser(null);

    try {
      localStorage.removeItem('standard_datahub_jwt_token');
      localStorage.removeItem('datahub_wallet_user_0');
      localStorage.removeItem('datahub_transactions_cache');
    } catch (e) {
      // ignore
    }

    // Notify App to navigate to login tab immediately
    window.dispatchEvent(new CustomEvent('auth-logout'));
  };

  const updateBalance = (newBalanceNaira: number) => {
    if (!user) return;
    const rounded = Number(newBalanceNaira.toFixed(2));
    setUser(prev => prev ? ({
      ...prev,
      balanceNaira: rounded,
      balanceKobo: Math.round(rounded * 100)
    }) : null);

    // Wallet mutations are performed by authenticated backend routes, never by the browser.
  };

  return (
    <AuthContext.Provider value={{
      user,
      token,
      isLoading,
      hideBalance,
      isLoggedIn,
      toggleHideBalance,
      login,
      logout,
      signOut: logout,
      refreshUser,
      updateBalance
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

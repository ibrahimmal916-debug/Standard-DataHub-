import React, { useState, useEffect } from 'react';
import { isSupabaseConfigured, checkSupabaseTables, SUPABASE_RLS_SCHEMA_SQL, SupabaseHealth } from '../lib/supabase.ts';
import { AlertCircle, CheckCircle2, Copy, Check, Database, X, ChevronDown, ChevronUp } from 'lucide-react';

export const SupabaseBanner: React.FC = () => {
  const [health, setHealth] = useState<SupabaseHealth | null>(null);
  const [dismissed, setDismissed] = useState(false);
  const [showSqlModal, setShowSqlModal] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    checkSupabaseTables().then((res) => {
      setHealth(res);
    });
  }, []);

  // If Supabase is fully configured and all tables exist, don't show any warning banner
  if (health?.configured && health?.allTablesExist) {
    return null;
  }

  // If user dismissed warning for current session
  if (dismissed) {
    return null;
  }

  const handleCopySql = () => {
    navigator.clipboard.writeText(SUPABASE_RLS_SCHEMA_SQL);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <>
      <div className="bg-amber-500/10 border-b border-amber-500/30 text-amber-900 dark:text-amber-200 px-4 py-2.5 text-xs transition-all">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-2">
            <Database className="w-4 h-4 text-amber-500 shrink-0" />
            {!isSupabaseConfigured ? (
              <span>
                <strong>Supabase Notice:</strong> Running in local preview mode. Add{' '}
                <code className="bg-amber-500/20 px-1 py-0.5 rounded font-mono text-[11px]">VITE_SUPABASE_URL</code> and{' '}
                <code className="bg-amber-500/20 px-1 py-0.5 rounded font-mono text-[11px]">VITE_SUPABASE_ANON_KEY</code>{' '}
                for permanent Supabase cloud persistence.
              </span>
            ) : !health?.allTablesExist ? (
              <span>
                <strong>Supabase Schema Check:</strong> Tables (
                {!health?.tables.wallet ? 'wallet, ' : ''}
                {!health?.tables.data_plans ? 'data_plans, ' : ''}
                {!health?.tables.transactions ? 'transactions' : ''}
                ) require RLS setup in your Supabase project.
              </span>
            ) : null}
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={() => setShowSqlModal(true)}
              className="px-2.5 py-1 bg-amber-500/20 hover:bg-amber-500/30 text-amber-800 dark:text-amber-200 rounded-lg font-bold text-[11px] transition-colors cursor-pointer flex items-center gap-1"
            >
              <span>Setup Schema (RLS)</span>
            </button>
            <button
              type="button"
              onClick={() => setDismissed(true)}
              className="p-1 text-amber-600 dark:text-amber-400 hover:text-amber-800 dark:hover:text-amber-200 transition-colors cursor-pointer"
              title="Dismiss for session"
              aria-label="Dismiss banner"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* SQL Setup Modal */}
      {showSqlModal && (
        <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-center justify-center p-4 animate-in fade-in duration-200">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-2xl w-full p-6 text-white space-y-4 shadow-2xl max-h-[90vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Database className="w-5 h-5 text-emerald-400" />
                <h3 className="font-bold text-base">Supabase Database & RLS Schema</h3>
              </div>
              <button
                type="button"
                onClick={() => setShowSqlModal(false)}
                className="p-1 text-slate-400 hover:text-white rounded-lg transition-colors cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-300">
              Run this SQL query inside your Supabase project's <strong>SQL Editor</strong> to create all tables (
              <code className="text-emerald-400">wallet</code>,{' '}
              <code className="text-emerald-400">data_plans</code>,{' '}
              <code className="text-emerald-400">transactions</code>) with restrictive Row-Level Security: public read-only access for active data plans, and no direct browser access to wallet or transaction records.
            </p>

            <div className="relative flex-1 min-h-0 bg-slate-950 rounded-2xl border border-slate-800 p-3 overflow-hidden flex flex-col">
              <div className="flex items-center justify-between text-[11px] text-slate-400 border-b border-slate-800/80 pb-2 mb-2">
                <span>SQL Editor Script (PostgreSQL / Supabase)</span>
                <button
                  type="button"
                  onClick={handleCopySql}
                  className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-bold flex items-center gap-1.5 transition-colors cursor-pointer"
                >
                  {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'Copied to Clipboard!' : 'Copy SQL Script'}</span>
                </button>
              </div>

              <pre className="flex-1 overflow-auto text-[11px] font-mono text-emerald-300/90 leading-relaxed pr-2 select-all">
                {SUPABASE_RLS_SCHEMA_SQL}
              </pre>
            </div>

            <div className="flex items-center justify-between pt-1">
              <div className="text-[11px] text-slate-400">
                <span>Status: </span>
                <span className={health?.allTablesExist ? 'text-emerald-400 font-bold' : 'text-amber-400 font-bold'}>
                  {health?.allTablesExist ? 'All Tables Configured' : 'Tables Ready for Setup'}
                </span>
              </div>
              <button
                type="button"
                onClick={() => setShowSqlModal(false)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white rounded-xl transition-colors cursor-pointer"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
};

import React from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import { formatNaira } from '../lib/utils.ts';
import { useWalletVisibility } from '../hooks/useWalletVisibility.ts';
import { StandardLogo } from '../components/StandardLogo.tsx';
import { 
  Zap, 
  Wifi, 
  PhoneCall, 
  Wallet, 
  ArrowRight, 
  ShieldCheck, 
  Clock, 
  CheckCircle2, 
  Smartphone, 
  RotateCcw,
  Sparkles,
  TrendingUp,
  CreditCard,
  Download,
  Eye,
  EyeOff
} from 'lucide-react';

interface HomePageProps {
  setCurrentTab: (tab: string) => void;
  onOpenInstallModal?: () => void;
  apkUrl?: string | null;
}

export const HomePage: React.FC<HomePageProps> = ({ 
  setCurrentTab, 
  onOpenInstallModal, 
  apkUrl
}) => {
  const { user } = useAuth();
  const { isHidden, toggleVisibility, formatBalance } = useWalletVisibility();

  const networks = [
    { name: 'MTN', color: 'bg-amber-400 text-amber-950', plans: 'SME & Corporate', discount: 'Up to 3% Off' },
    { name: 'Airtel', color: 'bg-red-600 text-white', plans: 'Gifting & Corporate', discount: 'Up to 2% Off' },
    { name: 'Glo', color: 'bg-emerald-600 text-white', plans: 'Gifting & SME', discount: 'Up to 2.5% Off' },
    { name: '9mobile', color: 'bg-teal-800 text-white', plans: 'SME & Gifting', discount: 'Up to 2.5% Off' }
  ];

  return (
    <div className="space-y-8 pb-12 animate-in fade-in duration-300">
      {/* Hero Section */}
      <section className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-blue-900 via-slate-900 to-emerald-950 p-6 sm:p-10 border border-blue-800/40 shadow-2xl text-white">
        {/* Background decorative glow */}
        <div className="absolute top-0 right-0 -mr-20 -mt-20 w-80 h-80 bg-blue-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-80 h-80 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

        <div className="relative z-10 max-w-2xl">
          <div className="flex items-center gap-3 mb-4">
            <StandardLogo className="w-11 h-11" />
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-blue-500/20 text-blue-300 border border-blue-500/30 text-xs font-semibold">
              <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
              <span>Standard DataHub • Automated 24/7 VTU</span>
            </div>
          </div>

          <h1 className="text-3xl sm:text-5xl font-extrabold tracking-tight leading-tight">
            Cheapest Mobile Data & Airtime,{' '}
            <span className="bg-gradient-to-r from-blue-400 via-emerald-400 to-teal-300 bg-clip-text text-transparent">
              Instant Delivery.
            </span>
          </h1>

          <p className="mt-3 text-slate-300 text-sm sm:text-base leading-relaxed">
            Purchase SME, Gifting, and Corporate data bundles for MTN, Airtel, Glo, and 9mobile at wholesale rates. Powered by verified telecom gateways.
          </p>

          {/* Wallet Balance Card */}
          <div className="mt-6 p-4 rounded-2xl bg-slate-800/80 border border-slate-700/80 backdrop-blur-md flex flex-wrap items-center justify-between gap-4">
            <div>
              <span className="text-xs text-slate-400 block">
                {user ? `Active Wallet (${user.fullName})` : 'Wallet Balance'}
              </span>
              <span className="text-base font-bold text-white">
                {user ? user.fullName : 'Standard DataHub'}
              </span>
            </div>
            
            <div className="flex flex-wrap items-center gap-3">
              <div className="text-right">
                <span className="text-xs text-slate-400 block">Available Balance</span>
                <div className="flex items-center justify-end gap-1.5 mt-0.5">
                  <span className="text-xl sm:text-2xl font-black text-emerald-400 font-mono tracking-tight">
                    {formatBalance(user?.balanceNaira ?? 0.00)}
                  </span>
                  <button
                    type="button"
                    onClick={toggleVisibility}
                    className="p-1 rounded-lg bg-slate-700/60 hover:bg-slate-700 text-slate-300 hover:text-white transition-all cursor-pointer flex items-center justify-center"
                    title={isHidden ? 'Click to show balance' : 'Click to hide balance'}
                    aria-label="Toggle balance visibility"
                  >
                    {isHidden ? (
                      <EyeOff className="w-4 h-4 text-emerald-400" />
                    ) : (
                      <Eye className="w-4 h-4 text-emerald-400" />
                    )}
                  </button>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setCurrentTab('fund-wallet')}
                  className="px-3.5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs rounded-xl transition-all shadow-md shadow-emerald-600/20 cursor-pointer flex items-center gap-1.5"
                >
                  <Wallet className="w-3.5 h-3.5" />
                  <span>+ Fund Wallet</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Telecom Services Grid */}
      <section>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold text-slate-900 dark:text-white">Quick Telecom Services</h2>
          <span className="text-xs text-slate-500">Instant Automation</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {/* Buy Data Card */}
          <div
            onClick={() => setCurrentTab('buy-data')}
            className="group cursor-pointer rounded-2xl p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-blue-500 dark:hover:border-blue-500 shadow-sm hover:shadow-md transition-all"
          >
            <div className="w-12 h-12 rounded-xl bg-blue-500/10 text-blue-600 dark:text-blue-400 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <Wifi className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white group-hover:text-blue-600 transition-colors">
              Buy Mobile Data
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              MTN SME from ₦145/500MB, Airtel Corp, Glo & 9mobile gifting bundles with 30-day validity.
            </p>
            <div className="mt-4 flex items-center text-xs font-semibold text-blue-600 dark:text-blue-400 gap-1">
              <span>Purchase bundle</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Buy Airtime Card */}
          <div
            onClick={() => setCurrentTab('buy-airtime')}
            className="group cursor-pointer rounded-2xl p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-emerald-500 dark:hover:border-emerald-500 shadow-sm hover:shadow-md transition-all"
          >
            <div className="w-12 h-12 rounded-xl bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <PhoneCall className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white group-hover:text-emerald-600 transition-colors">
              Buy Airtime (Discounted)
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Instant VTU recharge with 2% to 2.5% discount across MTN, Airtel, Glo, and 9mobile.
            </p>
            <div className="mt-4 flex items-center text-xs font-semibold text-emerald-600 dark:text-emerald-400 gap-1">
              <span>Top up now</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>

          {/* Fund Wallet Card */}
          <div
            onClick={() => setCurrentTab('fund-wallet')}
            className="group cursor-pointer rounded-2xl p-5 bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 hover:border-amber-500 dark:hover:border-amber-500 shadow-sm hover:shadow-md transition-all"
          >
            <div className="w-12 h-12 rounded-xl bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <Wallet className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white group-hover:text-amber-600 transition-colors">
              Fund Wallet
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Manual bank transfer with prompt admin credit. Verified ledger tracking for every transaction.
            </p>
            <div className="mt-4 flex items-center text-xs font-semibold text-amber-600 dark:text-amber-400 gap-1">
              <span>Bank details & form</span>
              <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        </div>
      </section>

      {/* Supported Networks Banner */}
      <section className="rounded-3xl bg-slate-900 border border-slate-800 p-6 text-white">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-4">
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Zap className="w-5 h-5 text-amber-400" />
              <span>Direct Gateway Networks</span>
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Automated API dispatch across all 4 major Nigerian telecommunication networks
            </p>
          </div>
          <span className="text-xs px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 font-semibold self-start sm:self-auto">
            100% Up-Time Server
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {networks.map((net) => (
            <div
              key={net.name}
              className="p-4 rounded-2xl bg-slate-800/60 border border-slate-700/60 flex flex-col justify-between"
            >
              <div className="flex items-center justify-between mb-2">
                <span className={`px-2.5 py-1 rounded-lg text-xs font-black tracking-wide ${net.color}`}>
                  {net.name}
                </span>
                <span className="text-[11px] font-semibold text-emerald-400">{net.discount}</span>
              </div>
              <span className="text-xs text-slate-300 font-medium">{net.plans}</span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
};

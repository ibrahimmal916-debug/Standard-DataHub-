import { supabase, isSupabaseConfigured } from './supabase.ts';
import { DataPlan, Transaction, NetworkType } from '../types/index.ts';

/**
 * Fallback verified Nigerian data plans used when Supabase is not connected or empty
 */
export const DEFAULT_DATA_PLANS: DataPlan[] = [
  { id: 'mtn-500mb', network: 'MTN', planName: 'MTN 500MB SME', planType: 'SME', dataAmount: '500MB', duration: '30 Days', sellingPriceKobo: 14500, sellingPriceNaira: 145.00, providerCode: '500', isActive: true },
  { id: 'mtn-1gb', network: 'MTN', planName: 'MTN 1GB SME', planType: 'SME', dataAmount: '1GB', duration: '30 Days', sellingPriceKobo: 28500, sellingPriceNaira: 285.00, providerCode: '1000', isActive: true },
  { id: 'mtn-2gb', network: 'MTN', planName: 'MTN 2GB SME', planType: 'SME', dataAmount: '2GB', duration: '30 Days', sellingPriceKobo: 57000, sellingPriceNaira: 570.00, providerCode: '2000', isActive: true },
  { id: 'mtn-3gb', network: 'MTN', planName: 'MTN 3GB SME', planType: 'SME', dataAmount: '3GB', duration: '30 Days', sellingPriceKobo: 85500, sellingPriceNaira: 855.00, providerCode: '3000', isActive: true },
  { id: 'mtn-5gb', network: 'MTN', planName: 'MTN 5GB SME', planType: 'SME', dataAmount: '5GB', duration: '30 Days', sellingPriceKobo: 142500, sellingPriceNaira: 1425.00, providerCode: '5000', isActive: true },
  { id: 'mtn-10gb', network: 'MTN', planName: 'MTN 10GB SME', planType: 'SME', dataAmount: '10GB', duration: '30 Days', sellingPriceKobo: 285000, sellingPriceNaira: 2850.00, providerCode: '10000', isActive: true },
  { id: 'airtel-500mb', network: 'AIRTEL', planName: 'Airtel 500MB Corporate', planType: 'Corporate', dataAmount: '500MB', duration: '30 Days', sellingPriceKobo: 15000, sellingPriceNaira: 150.00, providerCode: 'Airtel500MB', isActive: true },
  { id: 'airtel-1gb', network: 'AIRTEL', planName: 'Airtel 1GB Corporate', planType: 'Corporate', dataAmount: '1GB', duration: '30 Days', sellingPriceKobo: 29000, sellingPriceNaira: 290.00, providerCode: 'Airtel1GB', isActive: true },
  { id: 'airtel-2gb', network: 'AIRTEL', planName: 'Airtel 2GB Corporate', planType: 'Corporate', dataAmount: '2GB', duration: '30 Days', sellingPriceKobo: 58000, sellingPriceNaira: 580.00, providerCode: 'Airtel2GB', isActive: true },
  { id: 'airtel-5gb', network: 'AIRTEL', planName: 'Airtel 5GB Corporate', planType: 'Corporate', dataAmount: '5GB', duration: '30 Days', sellingPriceKobo: 145000, sellingPriceNaira: 1450.00, providerCode: 'Airtel5GB', isActive: true },
  { id: 'glo-1gb', network: 'GLO', planName: 'Glo 1GB Gifting', planType: 'Gifting', dataAmount: '1GB', duration: '30 Days', sellingPriceKobo: 26000, sellingPriceNaira: 260.00, providerCode: '1000', isActive: true },
  { id: 'glo-2gb', network: 'GLO', planName: 'Glo 2GB Gifting', planType: 'Gifting', dataAmount: '2GB', duration: '30 Days', sellingPriceKobo: 52000, sellingPriceNaira: 520.00, providerCode: '2000', isActive: true },
  { id: 'glo-5gb', network: 'GLO', planName: 'Glo 5GB Gifting', planType: 'Gifting', dataAmount: '5GB', duration: '30 Days', sellingPriceKobo: 130000, sellingPriceNaira: 1300.00, providerCode: '5000', isActive: true },
  { id: '9mobile-1gb', network: '9MOBILE', planName: '9mobile 1GB SME', planType: 'SME', dataAmount: '1GB', duration: '30 Days', sellingPriceKobo: 24000, sellingPriceNaira: 240.00, providerCode: '1000', isActive: true },
  { id: '9mobile-2gb', network: '9MOBILE', planName: '9mobile 2GB SME', planType: 'SME', dataAmount: '2GB', duration: '30 Days', sellingPriceKobo: 48000, sellingPriceNaira: 480.00, providerCode: '2000', isActive: true }
];

export interface WalletRecord {
  id: string;
  user_id: string;
  balance: number;
}

/**
 * Fetch or initialize wallet for given user from Supabase.
 * Always defaults safely to 0.00.
 */
export async function getSupabaseWallet(userId: string): Promise<number> {
  if (!userId) throw new Error('A valid user ID is required to load a wallet.');
  if (!isSupabaseConfigured) throw new Error('Supabase is not configured; wallet data is unavailable.');
  const { data, error } = await supabase.from('wallet').select('balance').eq('user_id', userId).single();
  if (error) throw new Error(`Could not load wallet from Supabase: ${error.message}`);
  if (!data || typeof data.balance !== 'number') throw new Error('Wallet record is missing or invalid in Supabase.');
  return Number(data.balance.toFixed(2));
}

export async function updateSupabaseWallet(userId: string, newBalance: number): Promise<boolean> {
  if (!userId || !Number.isFinite(newBalance) || newBalance < 0) return false;
  if (!isSupabaseConfigured) throw new Error('Supabase is not configured; wallet update was not saved.');
  const rounded = Number(newBalance.toFixed(2));
  const { error } = await supabase.from('wallet').update({ balance: rounded, updated_at: new Date().toISOString() }).eq('user_id', userId);
  if (error) throw new Error(`Wallet update failed; no local fallback was used: ${error.message}`);
  return true;
}

/**
 * Fetch Data Plans from Supabase data_plans table.
 * Falls back to DEFAULT_DATA_PLANS if table is missing or empty.
 */
export async function fetchSupabaseDataPlans(network?: string): Promise<DataPlan[]> {
  try {
    if (isSupabaseConfigured) {
      let query = supabase.from('data_plans').select('*').eq('is_active', true);
      if (network) {
        query = query.eq('network', network.toUpperCase());
      }
      const { data, error } = await query;
      if (!error && Array.isArray(data) && data.length > 0) {
        return data.map((d: any) => ({
          id: d.id,
          network: d.network,
          planName: d.plan_name,
          planType: d.plan_type || 'SME',
          dataAmount: d.data_amount,
          duration: d.duration || '30 Days',
          sellingPriceKobo: Number(d.selling_price_kobo),
          sellingPriceNaira: Number(d.selling_price_naira || (d.selling_price_kobo / 100)),
          providerCode: d.provider_code,
          isActive: d.is_active
        }));
      }
    }
  } catch (err) {
    console.warn('[SupabaseService] data_plans fetch fallback:', err);
  }

  throw new Error('Could not load data plans from Supabase. Check cloud configuration and table access.');
}

/**
 * Record a transaction in Supabase
 */
export async function recordSupabaseTransaction(tx: {
  reference: string;
  userId: string;
  productType: 'data' | 'airtime';
  network: string;
  recipientPhone: string;
  amountNaira: number;
  sellingPriceKobo: number;
  status: 'SUCCESS' | 'FAILED_REFUNDED' | 'pending';
  providerReference?: string;
  refundReference?: string;
  errorMessage?: string;
}): Promise<void> {
  if (!isSupabaseConfigured) throw new Error('Supabase is not configured; transaction was not saved.');
  const { error } = await supabase.from('transactions').insert([{
    reference: tx.reference, user_id: tx.userId, product_type: tx.productType,
    network: tx.network, recipient_phone: tx.recipientPhone, amount_naira: tx.amountNaira,
    selling_price_kobo: tx.sellingPriceKobo, status: tx.status, provider: 'ClubKonnect',
    provider_reference: tx.providerReference || null, refund_reference: tx.refundReference || null,
    error_message: tx.errorMessage || null, created_at: new Date().toISOString()
  }]);
  if (error) throw new Error(`Transaction was not saved to Supabase: ${error.message}`);
}

/**
 * ClubKonnect API helper with Retry logic (tries 2 times before failing).
 * Returns structured result and never throws fatal crash.
 */
export async function callClubKonnectWithRetry(
  url: string,
  maxAttempts = 2
): Promise<{ ok: boolean; data: any; rawText?: string; error?: string }> {
  let lastError = '';

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    try {
      console.log(`[ClubKonnect] Dispatching request (Attempt ${attempt}/${maxAttempts})...`);
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 15000);

      const response = await fetch(url, {
        method: 'GET',
        headers: { 'Accept': 'application/json, text/plain, */*' },
        signal: controller.signal
      });
      clearTimeout(timeoutId);

      const text = await response.text();
      console.log(`[ClubKonnect] Response attempt ${attempt} status ${response.status}:`, text.slice(0, 150));

      if (response.status === 503 || text.includes('Service Temporarily Unavailable') || text.includes('503 Service')) {
        lastError = 'Service Temporarily Unavailable';
        if (attempt < maxAttempts) {
          await new Promise(r => setTimeout(r, 1000));
          continue;
        }
        return { ok: false, data: null, rawText: text, error: 'Service Temporarily Unavailable' };
      }

      let parsed: any = null;
      try {
        parsed = JSON.parse(text);
      } catch {
        parsed = { raw: text };
      }

      const statusCode = String(parsed?.statuscode || parsed?.StatusCode || '').trim();
      const statusText = String(parsed?.status || parsed?.orderstatus || '').toUpperCase().trim();

      const isSuccess =
        statusCode === '100' ||
        statusCode === '101' ||
        statusCode === '200' ||
        statusText === 'ORDER_COMPLETED' ||
        statusText === 'ORDER_RECEIVED' ||
        statusText === 'SUCCESS' ||
        statusText === 'SUCCESSFUL';

      if (isSuccess) {
        return { ok: true, data: parsed, rawText: text };
      }

      // If provider explicitly reported invalid or error
      const msg = parsed?.msg || parsed?.error || parsed?.message || parsed?.remark || 'Service Temporarily Unavailable';
      lastError = msg;

      if (attempt < maxAttempts) {
        await new Promise(r => setTimeout(r, 1000));
        continue;
      }

      return { ok: false, data: parsed, rawText: text, error: lastError };
    } catch (err: any) {
      lastError = err?.message || 'Service Temporarily Unavailable';
      console.warn(`[ClubKonnect] Attempt ${attempt} network error:`, lastError);
      if (attempt < maxAttempts) {
        await new Promise(r => setTimeout(r, 1000));
        continue;
      }
    }
  }

  return { ok: false, data: null, error: lastError || 'Service Temporarily Unavailable' };
}

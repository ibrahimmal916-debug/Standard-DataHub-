import { createClient, type SupabaseClient } from '@supabase/supabase-js';

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL;
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY;

export const isSupabaseConfigured = Boolean(
  typeof SUPABASE_URL === 'string' && /^https:\/\//i.test(SUPABASE_URL) &&
  !/your-project|placeholder|example/i.test(SUPABASE_URL) &&
  typeof SUPABASE_ANON_KEY === 'string' && SUPABASE_ANON_KEY.trim().length > 20 &&
  !/your-|placeholder|example/i.test(SUPABASE_ANON_KEY)
);

// No mock client: if cloud configuration is missing, requests fail visibly instead of
// returning fake data or reporting successful writes.
export const supabase: SupabaseClient = isSupabaseConfigured
  ? createClient(SUPABASE_URL!, SUPABASE_ANON_KEY!)
  : createClient('https://configuration-required.invalid', 'configuration-required-anon-key');

export interface SupabaseHealth {
  configured: boolean;
  url?: string;
  tables: { wallet: boolean; data_plans: boolean; transactions: boolean };
  allTablesExist: boolean;
  error?: string;
}

export async function checkSupabaseTables(): Promise<SupabaseHealth> {
  const result: SupabaseHealth = {
    configured: isSupabaseConfigured,
    ...(isSupabaseConfigured ? { url: SUPABASE_URL } : {}),
    tables: { wallet: false, data_plans: false, transactions: false },
    allTablesExist: false
  };
  if (!isSupabaseConfigured) {
    result.error = 'Supabase is not configured. Set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY.';
    return result;
  }
  try {
    const checks = await Promise.all([
      supabase.from('wallet').select('id').limit(1),
      supabase.from('data_plans').select('id').limit(1),
      supabase.from('transactions').select('id').limit(1)
    ]);
    result.tables.wallet = !checks[0].error;
    result.tables.data_plans = !checks[1].error;
    result.tables.transactions = !checks[2].error;
    result.allTablesExist = Object.values(result.tables).every(Boolean);
    if (!result.allTablesExist) result.error = 'One or more Supabase tables are missing or inaccessible. Apply supabase-schema.sql.';
  } catch (error: any) {
    result.error = error?.message || 'Unable to contact Supabase.';
  }
  return result;
}

export async function fetchSupabaseTransactions(userId?: string): Promise<{ data: any[] | null; error: any }> {
  if (!isSupabaseConfigured) return { data: null, error: new Error('Supabase is not configured; transactions were not loaded.') };
  try {
    let query = supabase.from('transactions').select('*').order('created_at', { ascending: false }).limit(100);
    if (userId && userId !== '0' && userId !== 'preview_user') query = query.eq('user_id', userId);
    return await query;
  } catch (error) {
    return { data: null, error };
  }
}

export const SUPABASE_RLS_SCHEMA_SQL = `-- Standard DataHub Supabase schema (apply in Supabase SQL Editor)
CREATE TABLE IF NOT EXISTS public.wallet (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), user_id TEXT NOT NULL UNIQUE,
  balance NUMERIC(14,2) NOT NULL DEFAULT 0 CHECK (balance >= 0),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(), updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS public.data_plans (
  id TEXT PRIMARY KEY, network TEXT NOT NULL, plan_name TEXT NOT NULL,
  plan_type TEXT NOT NULL DEFAULT 'SME', data_amount TEXT NOT NULL,
  duration TEXT NOT NULL DEFAULT '30 Days', selling_price_kobo NUMERIC NOT NULL CHECK (selling_price_kobo >= 0),
  selling_price_naira NUMERIC NOT NULL CHECK (selling_price_naira >= 0), provider_code TEXT NOT NULL,
  is_active BOOLEAN NOT NULL DEFAULT true, created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS public.transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(), reference TEXT NOT NULL UNIQUE,
  user_id TEXT NOT NULL, product_type TEXT NOT NULL CHECK (product_type IN ('data','airtime')),
  network TEXT NOT NULL, recipient_phone TEXT NOT NULL, amount_naira NUMERIC NOT NULL CHECK (amount_naira >= 0),
  selling_price_kobo NUMERIC NOT NULL CHECK (selling_price_kobo >= 0), status TEXT NOT NULL,
  provider TEXT DEFAULT 'ClubKonnect', provider_reference TEXT, refund_reference TEXT, error_message TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(), updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.wallet ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.data_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.transactions ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "allow_all" ON public.wallet;
DROP POLICY IF EXISTS "allow_all" ON public.data_plans;
DROP POLICY IF EXISTS "allow_all" ON public.transactions;
DROP POLICY IF EXISTS "data_plans_public_read" ON public.data_plans;
CREATE POLICY "data_plans_public_read" ON public.data_plans FOR SELECT TO anon, authenticated USING (is_active = true);
-- No browser policies for wallet or transactions: access is server-side only.
`;
